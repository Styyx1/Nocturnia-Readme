### Known Issues

- snow is very bright in some weathers at some places
- not an issue but worth noting: Key for the starter home in Riverwood needs to be stolen and won't be granted automatically.
- sometimes after dying, 3rd person view breaks. Go into an interior and leave it. wait until your body catches up to you, that should fix it


