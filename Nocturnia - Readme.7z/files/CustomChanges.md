# Custom Changes

**Some mechanics/mods are changed by me so the mod pages may not always be accurate**  
I try to keep track of the most important changes

- Standing Stones: Only the 3 Guardian Stones are free to use, the other ones are guarded by enemies. You need to explore the surroundings (including dungeons) to find them.
- Potion of Obtainable Progress: locations are random with every update (unless I forget) (currently not implemented but will be later on)


## Random Changes 
- Inn Cost: 150 - 2000
- Carriage Cost: 100 --> 150 | 200 --> 250
- attack turn angle set to roughly 10% of vanilla
- magic attack turn slowed down
- many movement speed changes
- damage ranges to melee, bow and spell attacks
- jump height changes based on your mass
- stamina regenerates slower when your inventory is more than 50% full
- jump height is lower when you're sneaking

## planned but not done yet:

- streamline starting options
- add player homes
- maybe balance out followers a bit better
- rogue-like deaths 