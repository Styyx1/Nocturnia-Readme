# Beta Releases

Every once in a while I might release a beta version of the updates for the list to test for stability of the main release. You will know about these betas from the support channel in the Discord server.
To install the Beta version head over to the [Release page](https://github.com/Styyx1/Nocturnia-Readme/releases/)

1. Download the latest Beta release
2. remember the download location of the file, you need it once it's finished
3. open the Wabbajack app and click on ``install from Disk``
4. locate the downloaded ``Nocturnia.wabbajack`` inside the line 'Target Modlist'
5. Fill in install and download location and hit the play icon
6. Now the waiting game begins, it'll take a while depending on your connection

## I highly suggest using a single download location for all your Wabbajack mod list downloads
