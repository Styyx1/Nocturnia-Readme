# Gamepad Controls 

This list is completely made with a controller in mind cause I only play with gamepads. 

### Controller Layout:
<img src="https://raw.githubusercontent.com/Styyx1/Nocturnia-Readme/af679fea23423cdb829f30c9f988cc6545bb33df/files/NocturniaGamepadLayout.png" />

### Gamepad mod used: 
- [Modern Controlmap (Gamepad and Keyboard)](https://www.nexusmods.com/skyrimspecialedition/mods/89649)


### Wheeler Menu
- Open with: B/Circle  
- Open in menu to assign stuff: Press right stick  
- new wheel: D-Pad Up
- new Item card: D-Pad down
- assign item to currently selected spot in the wheel: RT

<img src="https://raw.githubusercontent.com/Styyx1/Nocturnia-Readme/master/files/WheelerMenuLayout.png"/>





